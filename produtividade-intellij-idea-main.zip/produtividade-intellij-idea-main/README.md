# produtividade-intellij-idea
Aprendendo atalhos ou snippets que aumentam a produtividade da IDE Intellij Idea para desenvolvimento em Java.
